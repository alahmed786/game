
import React from 'react';
import { View, Theme } from '../types';

interface NavigationProps {
  currentView: View;
  onViewChange: (view: View) => void;
  theme: Theme;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onViewChange, theme }) => {
  const tabs: { id: View; label: string; icon: string }[] = [
    { id: 'Earn', label: 'Galaxy', icon: '👽' },
    { id: 'Upgrades', label: 'Fleet', icon: '🚀' },
    { id: 'Tasks', label: 'Missions', icon: '🎯' },
    { id: 'Leaderboard', label: 'Empire', icon: '🌌' },
    { id: 'Wallet', label: 'Wallet', icon: '🏦' },
  ];

  return (
    <nav className={`fixed bottom-4 left-4 right-4 bg-black/80 backdrop-blur-xl border border-${theme}-400/50 shadow-[0_0_20px_rgba(var(--bg-primary),0.4),inset_0_0_10px_rgba(var(--bg-primary),0.1)] rounded-3xl flex justify-around items-center p-2 z-50 transition-all duration-300`}>
      {tabs.map((tab) => {
        const isActive = currentView === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onViewChange(tab.id)}
            className={`relative w-1/5 flex flex-col items-center gap-1 transition-all duration-300 py-2 rounded-2xl ${
              isActive ? `text-${theme}-300` : 'text-slate-500'
            }`}
          >
            <div className={`relative ${isActive ? 'active-nav-glow scale-110' : 'inactive-nav-glow'}`}>
              <span className="text-2xl drop-shadow-md filter">{tab.icon}</span>
            </div>
            <span className={`text-[10px] font-bold uppercase tracking-wider transition-colors ${isActive ? `text-${theme}-300 drop-shadow-[0_0_8px_rgba(var(--bg-primary),0.6)]` : ''}`}>{tab.label}</span>
          </button>
        )
      })}
    </nav>
  );
};

export default Navigation;
