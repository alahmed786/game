
import React, { useState, useMemo, useEffect } from 'react';
import { Player, Withdrawal, Theme, WalletViewProps } from '../types';
import { WITHDRAWAL_COOLDOWN_MS } from '../constants';

const DUST_TO_TON_RATE = 100000;
const TON_TO_USD_RATE = 7.5; 
const TON_TO_INR_RATE = 640; 

const formatCountdown = (ms: number) => {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
};

const getStatusStyles = (status: Withdrawal['status']) => {
  switch (status) {
    case 'Paid': return 'text-emerald-400 border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.3)] bg-emerald-950/30';
    case 'Pending': return 'text-amber-400 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.3)] bg-amber-950/30';
    case 'Rejected': return 'text-red-400 border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.3)] bg-red-950/30';
    default: return 'text-slate-400 border-slate-500/30 bg-slate-900/30';
  }
};

const VerificationModal: React.FC<{ 
  step: number; 
  onComplete: () => void; 
  onCancel: () => void; 
  theme: string;
  onShowAd: WalletViewProps['onShowAd'];
}> = ({ step, onComplete, onCancel, theme, onShowAd }) => {
  const [isWatching, setIsWatching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleWatch = () => {
    setIsWatching(true);
    setError(null);
    onShowAd(
        () => {
            setIsWatching(false);
            onComplete();
        },
        (msg) => {
            setIsWatching(false);
            setError(msg);
        }
    );
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xl flex items-center justify-center z-50 p-6 animate-fade-in">
        <div className={`w-full max-w-sm bg-slate-900 border border-${theme}-500/30 rounded-2xl p-6 flex flex-col items-center gap-6 relative overflow-hidden shadow-2xl`}>
            
            {/* Background Animation */}
            <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-${theme}-500 to-transparent animate-scan`}></div>
            <div className={`absolute -bottom-20 -right-20 w-40 h-40 bg-${theme}-500/10 blur-[50px] rounded-full`}></div>

            <div className="flex flex-col items-center text-center gap-2 z-10">
                <div className={`w-16 h-16 rounded-full bg-${theme}-500/10 border border-${theme}-500/30 flex items-center justify-center mb-2 shadow-[0_0_20px_rgba(var(--bg-primary),0.2)]`}>
                    <span className="text-3xl animate-pulse">🛡️</span>
                </div>
                <h2 className="text-lg font-black text-white uppercase tracking-widest">
                    Security Protocol
                </h2>
                <p className="text-xs text-slate-400 font-mono leading-relaxed">
                    High-value transfer detected. Multi-factor authentication required to verify commander identity.
                </p>
            </div>

            {/* Progress Steps */}
            <div className="flex items-center gap-2 w-full justify-center">
                <div className={`h-1.5 flex-1 rounded-full transition-colors ${step >= 0 ? `bg-${theme}-500 shadow-[0_0_10px_rgba(var(--bg-primary),0.5)]` : 'bg-slate-800'}`}></div>
                <div className={`h-1.5 flex-1 rounded-full transition-colors ${step >= 1 ? `bg-${theme}-500 shadow-[0_0_10px_rgba(var(--bg-primary),0.5)]` : 'bg-slate-800'}`}></div>
            </div>

            {error && <p className="text-red-400 text-xs font-bold uppercase z-10">{error}</p>}

            <div className="flex flex-col w-full gap-3 z-10">
                <button 
                    onClick={handleWatch}
                    disabled={isWatching}
                    className={`w-full py-4 rounded-xl font-bold text-xs uppercase tracking-[0.15em] flex items-center justify-center gap-3 transition-all
                        ${isWatching 
                            ? 'bg-slate-800 text-slate-500 cursor-wait border border-slate-700' 
                            : `bg-gradient-to-r from-${theme}-600 to-blue-600 text-white shadow-[0_0_20px_rgba(var(--bg-primary),0.3)] hover:scale-[1.02] active:scale-[0.98] border border-white/10`
                        }
                    `}
                >
                    {isWatching ? (
                        <>
                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            <span>Verifying...</span>
                        </>
                    ) : (
                        <>
                            <span>{step === 0 ? 'Initialize Link 1/2' : 'Finalize Link 2/2'}</span>
                            <span className="bg-black/30 px-2 py-0.5 rounded text-[9px] border border-white/10">AD</span>
                        </>
                    )}
                </button>
                
                <button 
                    onClick={onCancel}
                    disabled={isWatching}
                    className="text-[10px] text-slate-500 font-bold uppercase tracking-widest hover:text-red-400 transition-colors py-2"
                >
                    Abort Transfer
                </button>
            </div>
        </div>
    </div>
  );
};

const TransactionCard: React.FC<{ withdrawal: Withdrawal; isIndiaMode: boolean; theme: string }> = ({ withdrawal, isIndiaMode, theme }) => {
  const date = new Date(withdrawal.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  const time = new Date(withdrawal.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const isUpi = withdrawal.method === 'UPI';
  
  const displayAmount = isUpi 
    ? `₹${(withdrawal.amountTon * TON_TO_INR_RATE).toLocaleString(undefined, {maximumFractionDigits: 0})}`
    : `${withdrawal.amountTon.toFixed(2)} TON`;

  return (
    <div className={`relative group overflow-hidden rounded-xl bg-slate-900/40 border border-white/5 p-4 transition-all hover:bg-slate-800/60 hover:border-${theme}-500/30 hover:shadow-[0_0_15px_rgba(var(--bg-primary),0.1)]`}>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 pointer-events-none"></div>
        
        <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg border ${isUpi ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' : 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400'}`}>
                    {isUpi ? '₹' : '💎'}
                </div>
                <div className="flex flex-col">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">{isUpi ? 'Bank Transfer' : 'TON Withdrawal'}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{date} • {time}</span>
                </div>
            </div>
            
            <div className="flex flex-col items-end gap-1">
                 <span className={`text-sm font-black font-mono tracking-wider ${isUpi ? 'text-orange-200' : 'text-cyan-200'}`}>
                    {displayAmount}
                </span>
                <span className={`text-[9px] px-2 py-0.5 rounded border uppercase font-bold tracking-widest ${getStatusStyles(withdrawal.status)}`}>
                    {withdrawal.status}
                </span>
            </div>
        </div>
        
        {/* Address preview snippet */}
        <div className="mt-2 pt-2 border-t border-white/5 flex justify-between items-center opacity-60">
            <span className="text-[9px] text-slate-500 font-mono">DESTINATION</span>
            <span className="text-[9px] text-slate-400 font-mono tracking-wide truncate max-w-[150px]">
                {withdrawal.address}
            </span>
        </div>
    </div>
  )
}

const WalletView: React.FC<WalletViewProps> = ({ player, onWithdraw, theme, minWithdrawal, onShowAd }) => {
  const isIndiaMode = useMemo(() => {
    try {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        return timezone === 'Asia/Kolkata' || timezone === 'Asia/Calcutta';
    } catch {
        return false;
    }
  }, []);

  const [address, setAddress] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [cooldownRemaining, setCooldownRemaining] = useState<number>(0);
  
  // Verification State
  const [showVerify, setShowVerify] = useState(false);
  const [verifyStep, setVerifyStep] = useState(0);
  
  const tonBalance = player.balance / DUST_TO_TON_RATE;
  const inrBalance = tonBalance * TON_TO_INR_RATE;
  const usdBalance = tonBalance * TON_TO_USD_RATE;
  
  const minWithdrawalDisplay = isIndiaMode 
    ? `₹${(minWithdrawal * TON_TO_INR_RATE).toLocaleString()}`
    : `${minWithdrawal} TON`;

  const progressPercent = Math.min((tonBalance / minWithdrawal) * 100, 100);

  // Check cooldown timer
  useEffect(() => {
    const checkCooldown = () => {
        if (!player.lastWithdrawalTime) {
            setCooldownRemaining(0);
            return;
        }
        const timePassed = Date.now() - player.lastWithdrawalTime;
        const remaining = WITHDRAWAL_COOLDOWN_MS - timePassed;
        setCooldownRemaining(remaining > 0 ? remaining : 0);
    };

    checkCooldown();
    const interval = setInterval(checkCooldown, 1000);
    return () => clearInterval(interval);
  }, [player.lastWithdrawalTime]);

  const onCooldown = cooldownRemaining > 0;
  const canWithdraw = tonBalance >= minWithdrawal && !onCooldown;

  const handleInitiate = () => {
      // 1. Validation
      if (!address.trim()) {
        setMessage({ type: 'error', text: isIndiaMode ? 'Enter Valid UPI ID' : 'Enter Wallet Address' });
        return;
      }
      
      if (onCooldown) {
          setMessage({ type: 'error', text: 'Daily limit reached.' });
          return;
      }

      if (isIndiaMode) {
        if (!/^[\w.-]+@[\w.-]+$/.test(address)) {
            setMessage({ type: 'error', text: 'Invalid UPI Format' });
            return;
        }
      } else {
        if (address.length < 24) {
             setMessage({ type: 'error', text: 'Invalid TON Address' });
             return;
        }
      }

      if (tonBalance < minWithdrawal) {
        setMessage({ type: 'error', text: `Min: ${minWithdrawalDisplay}` });
        return;
      }

      // 2. Start Verification Protocol
      setVerifyStep(0);
      setShowVerify(true);
  };

  const handleVerificationComplete = () => {
      if (verifyStep === 0) {
          setVerifyStep(1);
      } else {
          setShowVerify(false);
          performWithdrawal();
      }
  };

  const performWithdrawal = () => {
    setIsAnimating(true);
    setTimeout(() => {
        onWithdraw({
            method: isIndiaMode ? 'UPI' : 'TON', 
            address: address,
            amountTon: tonBalance,
            amountStardust: player.balance,
        });
        setAddress('');
        setMessage({ type: 'success', text: 'Transfer Protocol Executed' });
        setIsAnimating(false);
        setTimeout(() => setMessage(null), 3000);
    }, 1500);
  };

  // Currency Context based on region (kept separate from theme)
  const walletContext = isIndiaMode ? {
    currency: 'INR',
    symbol: '₹',
    network: 'UPI Network',
    icon: '🇮🇳'
  } : {
    currency: 'TON',
    symbol: '💎',
    network: 'TON Mainnet',
    icon: '🌐'
  };

  return (
    <div className="pt-6 flex flex-col gap-6 pb-24 px-4 min-h-full">
        {showVerify && (
            <VerificationModal 
                step={verifyStep} 
                onComplete={handleVerificationComplete} 
                onCancel={() => setShowVerify(false)} 
                theme={theme}
                onShowAd={onShowAd}
            />
        )}
        
        {/* Header Title */}
        <div className="flex items-center justify-between">
            <div>
                <h1 className="text-2xl font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <span className="text-3xl">🏦</span> Treasury
                </h1>
                <p className="text-xs text-slate-400 font-mono tracking-wide">Manage your empire's assets</p>
            </div>
            <div className={`px-3 py-1 rounded-full bg-black/40 border border-white/10 flex items-center gap-2 text-${theme}-400`}>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 bg-current"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-current"></span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider">{walletContext.network}</span>
            </div>
        </div>

        {/* Quantum Wallet Node Card */}
        <div className="relative group perspective-1000">
            <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br from-${theme}-900/40 to-slate-900/80 border border-${theme}-500/50 p-6 shadow-2xl transition-transform duration-500 group-hover:scale-[1.01]`}>
                
                {/* Background Tech Patterns */}
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
                
                <div className="relative z-10 flex flex-col gap-6">
                    <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
                                <span className="text-lg">{walletContext.icon}</span>
                            </div>
                            <span className="text-[10px] text-white/50 font-mono uppercase tracking-[0.2em]">Secure Node</span>
                        </div>
                        <div className="text-right">
                             <span className={`text-3xl font-black text-white tracking-tighter drop-shadow-[0_0_10px_rgba(255,255,255,0.3)] block`}>
                                {isIndiaMode 
                                    ? inrBalance.toLocaleString(undefined, {maximumFractionDigits: 2})
                                    : tonBalance.toFixed(4)
                                } <span className="text-base align-top opacity-70 ml-1">{walletContext.currency}</span>
                             </span>
                             <span className="text-[10px] text-white/40 font-mono">
                                {isIndiaMode 
                                    ? `≈ ${tonBalance.toFixed(4)} TON`
                                    : `≈ $${usdBalance.toFixed(2)} USD`
                                }
                             </span>
                        </div>
                    </div>

                    {/* Progress Visualizer */}
                    <div className="flex flex-col gap-2">
                        <div className="flex justify-between text-[9px] font-bold uppercase text-white/60 tracking-wider">
                            <span>Withdrawal Threshold</span>
                            <span className={canWithdraw && !onCooldown ? 'text-emerald-400' : 'text-slate-400'}>
                                {Math.floor(progressPercent)}%
                            </span>
                        </div>
                        <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden border border-white/5 relative">
                             {/* Scanline animation inside bar */}
                             <div className="absolute top-0 bottom-0 w-full bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.1),transparent)] animate-[shine_2s_infinite]"></div>
                             
                            <div 
                                className={`h-full transition-all duration-1000 ease-out relative ${canWithdraw && !onCooldown ? 'bg-gradient-to-r from-emerald-500 to-green-400' : `bg-gradient-to-r from-slate-600 to-slate-500`}`}
                                style={{ width: `${progressPercent}%` }}
                            >
                                <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-white shadow-[0_0_5px_white]"></div>
                            </div>
                        </div>
                        <div className="text-[9px] text-white/30 font-mono text-right">
                            Target: {minWithdrawalDisplay}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Transfer Console */}
        <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between pl-1">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2">
                    <span>⚡</span> Transfer Protocol
                </h3>
                <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded border ${onCooldown ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'}`}>
                    {onCooldown ? 'Limit Reached' : 'Ready'}
                </span>
            </div>
            
            <div className="bg-slate-900/60 backdrop-blur-xl border border-white/5 rounded-2xl p-1 flex flex-col gap-2 relative shadow-lg">
                <div className="relative">
                    <input 
                        type="text" 
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder={isIndiaMode ? "user@upi" : "UQ..."}
                        disabled={onCooldown}
                        className={`w-full bg-black/40 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-sm font-mono text-${theme}-100 placeholder:text-slate-700 outline-none transition-all focus:border-${theme}-500/50 focus:bg-slate-900/80 focus:shadow-[0_0_20px_rgba(var(--bg-primary),0.1)] disabled:opacity-50 disabled:cursor-not-allowed`}
                    />
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">
                        {isIndiaMode ? '💳' : '⛓️'}
                    </div>
                </div>
                
                <button
                    onClick={handleInitiate}
                    disabled={!canWithdraw || isAnimating || onCooldown}
                    className={`
                        w-full h-14 rounded-xl font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all duration-300 relative overflow-hidden group
                        ${canWithdraw && !onCooldown
                            ? `bg-gradient-to-r from-${theme}-500 to-blue-600 text-white shadow-lg active:scale-[0.98]` 
                            : 'bg-slate-800 text-slate-600 cursor-not-allowed border border-white/5'}
                    `}
                >
                    {isAnimating ? (
                         <div className="flex items-center gap-2">
                             <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                             <span>PROCESSING...</span>
                         </div>
                    ) : onCooldown ? (
                        <div className="flex flex-col items-center leading-tight">
                            <span className="text-amber-500">COOLDOWN ACTIVE</span>
                            <span className="text-[10px] font-mono text-white">{formatCountdown(cooldownRemaining)}</span>
                        </div>
                    ) : (
                        <>
                            <span>INITIATE TRANSFER</span>
                            {canWithdraw && <span className="group-hover:translate-x-1 transition-transform">➡️</span>}
                        </>
                    )}
                </button>
            </div>
             {message && (
                <div className={`text-center text-[10px] font-bold uppercase tracking-widest p-3 rounded-xl border animate-fade-in flex items-center justify-center gap-2 ${message.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                    <span>{message.type === 'success' ? '✅' : '⚠️'}</span>
                    {message.text}
                </div>
            )}
        </div>

        {/* Transaction Ledger */}
        <div className="flex flex-col gap-3 flex-1">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] pl-1 flex items-center gap-2">
                <span>📟</span> Data Log
            </h3>
            
            <div className="flex flex-col gap-2.5">
                {player.withdrawalHistory.length > 0 ? (
                    player.withdrawalHistory.map(tx => <TransactionCard key={tx.id} withdrawal={tx} isIndiaMode={isIndiaMode} theme={theme} />)
                ) : (
                    <div className="flex flex-col items-center justify-center py-10 border border-dashed border-slate-800 rounded-2xl bg-slate-900/20 text-slate-600 gap-2">
                        <span className="text-3xl opacity-20 grayscale">📂</span>
                        <span className="text-[10px] font-bold uppercase tracking-widest opacity-50">No Data Found</span>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default WalletView;
